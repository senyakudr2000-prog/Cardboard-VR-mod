package com.armvr.mod;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.client.event.RenderHandEvent;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;
import org.joml.Quaternionf;

/**
 * Рисует руки игрока по данным трекинга (от первого лица).
 * Каждая рука = два сегмента (плечо и предплечье), в каждом — половинка модели руки со скином игрока.
 * Направления приходят в системе тела (вправо, вверх, вперёд); тело повёрнуто туда же, куда смотрит камера
 * (поворотом головы управляет гироскоп Zalith).
 */
public final class ArmRenderer {
    private static final float SEG = 0.3125f;          // половина видимой длины руки Minecraft (10 px от плеча = 0.625 блока)
    private static final float SHOULDER_X = 0.3125f;   // вынос плеча в сторону
    private static final float SHOULDER_BELOW_EYE = 0.244f;

    // покой: руки опущены (вправо, вверх, вперёд), единичные векторы
    private static final float[] REST = norm(new float[]{
            0.05f, -1f, 0.08f, 0.05f, -1f, 0.35f,
            -0.05f, -1f, 0.08f, -0.05f, -1f, 0.35f});
    private static final float[] cur = REST.clone();
    private static long lastNs = 0L;

    private ArmRenderer() {}

    private static float[] norm(float[] a) {
        for (int o = 0; o < a.length; o += 3) normSeg(a, o);
        return a;
    }

    private static void normSeg(float[] a, int o) {
        float l = (float) Math.sqrt(a[o] * a[o] + a[o + 1] * a[o + 1] + a[o + 2] * a[o + 2]);
        if (l < 1e-5f) {
            a[o] = 0; a[o + 1] = -1; a[o + 2] = 0;
        } else {
            a[o] /= l; a[o + 1] /= l; a[o + 2] /= l;
        }
    }

    private static boolean enabled() {
        return Settings.arms && TrackingState.active();
    }

    @SubscribeEvent
    public static void onHand(RenderHandEvent e) {
        if (Settings.hideHand && enabled()) e.setCanceled(true);
    }

    private static void smooth() {
        long now = System.nanoTime();
        float dt = lastNs == 0L ? 0.016f : Math.min(0.1f, (now - lastNs) / 1e9f);
        lastNs = now;
        TrackingState.Snap s = TrackingState.get();
        if (s == null) return;
        float k = 1f - (float) Math.exp(-dt * Settings.smooth);
        for (int arm = 0; arm < 2; arm++) {
            boolean valid = (s.flags() & (1 << arm)) != 0;
            for (int seg = 0; seg < 2; seg++) {
                int o = arm * 6 + seg * 3;
                for (int i = 0; i < 3; i++) {
                    float target = valid ? s.d()[o + i] : REST[o + i];
                    cur[o + i] += (target - cur[o + i]) * k;
                }
                normSeg(cur, o);
            }
        }
    }

    @SubscribeEvent
    public static void onLevel(RenderLevelStageEvent e) {
        if (e.getStage() != RenderLevelStageEvent.Stage.AFTER_ENTITIES) return;
        if (!enabled()) return;
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer pl = mc.player;
        if (pl == null || !mc.options.getCameraType().isFirstPerson()) return;

        EntityRenderer<?> r = mc.getEntityRenderDispatcher().getRenderer(pl);
        if (!(r instanceof PlayerRenderer pr)) return;
        PlayerModel<AbstractClientPlayer> model = pr.getModel();

        smooth();

        Camera cam = e.getCamera();
        Vec3 cp = cam.getPosition();
        double yaw = Math.toRadians(cam.getYRot());
        Vec3 fwd = new Vec3(-Math.sin(yaw), 0, Math.cos(yaw));
        Vec3 right = new Vec3(-Math.cos(yaw), 0, -Math.sin(yaw));

        float pt = mc.getDeltaTracker().getGameTimeDeltaPartialTick(true);
        Vec3 base = pl.getPosition(pt).add(0, pl.getEyeHeight() - SHOULDER_BELOW_EYE, 0);

        ResourceLocation tex = pl.getSkin().texture();
        RenderType rt = RenderType.entityCutoutNoCull(tex);
        MultiBufferSource.BufferSource bs = mc.renderBuffers().bufferSource();
        VertexConsumer vc = bs.getBuffer(rt);
        PoseStack ps = e.getPoseStack();

        for (int arm = 0; arm < 2; arm++) {
            boolean isRight = arm == 0;
            Vec3 shoulder = base.add(right.scale(isRight ? SHOULDER_X : -SHOULDER_X));
            Vec3 upper = toWorld(cur, arm * 6, right, fwd);
            Vec3 fore = toWorld(cur, arm * 6 + 3, right, fwd);
            ModelPart part = isRight ? model.rightArm : model.leftArm;
            ModelPart sleeve = isRight ? model.rightSleeve : model.leftSleeve;

            drawSegment(ps, vc, part, sleeve, shoulder, cp, upper);
            drawSegment(ps, vc, part, sleeve, shoulder.add(upper.scale(SEG)), cp, fore);
        }
        bs.endBatch(rt);
    }

    private static Vec3 toWorld(float[] c, int o, Vec3 right, Vec3 fwd) {
        return right.scale(c[o]).add(0, c[o + 1], 0).add(fwd.scale(c[o + 2])).normalize();
    }

    private static void drawSegment(PoseStack ps, VertexConsumer vc, ModelPart part, ModelPart sleeve,
                                    Vec3 start, Vec3 cam, Vec3 dir) {
        ps.pushPose();
        ps.translate(start.x - cam.x, start.y - cam.y, start.z - cam.z);
        // модель руки висит вниз (0,-1,0) после масштаба (-1,-1,1); поворачиваем её в нужное направление
        ps.mulPose(new Quaternionf().rotationTo(0f, -1f, 0f, (float) dir.x, (float) dir.y, (float) dir.z));
        ps.scale(-1f, -1f, 1f);
        ps.scale(1f, 0.5f, 1f);
        renderPart(ps, vc, part);
        if (sleeve != null) renderPart(ps, vc, sleeve);
        ps.popPose();
    }

    private static void renderPart(PoseStack ps, VertexConsumer vc, ModelPart p) {
        float x = p.x, y = p.y, z = p.z, xr = p.xRot, yr = p.yRot, zr = p.zRot;
        boolean vis = p.visible;
        p.setPos(0f, 0f, 0f);
        p.xRot = 0f; p.yRot = 0f; p.zRot = 0f;
        p.visible = true;
        p.render(ps, vc, LightTexture.FULL_BRIGHT, OverlayTexture.NO_OVERLAY, -1);
        p.setPos(x, y, z);
        p.xRot = xr; p.yRot = yr; p.zRot = zr;
        p.visible = vis;
    }
}
