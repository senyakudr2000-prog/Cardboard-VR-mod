package com.armvr.mod;

import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.context.CommandContext;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RegisterClientCommandsEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import org.lwjgl.glfw.GLFW;

public final class ClientEvents {
    public static final KeyMapping TOGGLE_STEREO =
            new KeyMapping("key.armvr.stereo", GLFW.GLFW_KEY_F8, "key.categories.armvr");
    public static final KeyMapping TOGGLE_ARMS =
            new KeyMapping("key.armvr.arms", GLFW.GLFW_KEY_F9, "key.categories.armvr");

    private ClientEvents() {}

    public static void registerKeys(RegisterKeyMappingsEvent e) {
        e.register(TOGGLE_STEREO);
        e.register(TOGGLE_ARMS);
    }

    private static void bar(String msg) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) mc.player.displayClientMessage(Component.literal(msg), true);
    }

    @SubscribeEvent
    public static void onTick(ClientTickEvent.Post e) {
        while (TOGGLE_STEREO.consumeClick()) {
            Settings.stereo = !Settings.stereo;
            Settings.save();
            bar("ArmVR стерео: " + (Settings.stereo ? "ВКЛ" : "выкл"));
        }
        while (TOGGLE_ARMS.consumeClick()) {
            Settings.arms = !Settings.arms;
            Settings.save();
            bar("ArmVR руки: " + (Settings.arms ? "ВКЛ" : "выкл"));
        }
    }

    private static int say(CommandContext<CommandSourceStack> c, String msg) {
        c.getSource().sendSuccess(() -> Component.literal(msg), false);
        return 1;
    }

    @SubscribeEvent
    public static void onCommands(RegisterClientCommandsEvent e) {
        e.getDispatcher().register(Commands.literal("armvr")
                .then(Commands.literal("stereo").executes(c -> {
                    Settings.stereo = !Settings.stereo;
                    Settings.save();
                    return say(c, "Стерео: " + (Settings.stereo ? "ВКЛ" : "выкл"));
                }))
                .then(Commands.literal("arms").executes(c -> {
                    Settings.arms = !Settings.arms;
                    Settings.save();
                    return say(c, "Руки: " + (Settings.arms ? "ВКЛ" : "выкл"));
                }))
                .then(Commands.literal("hand").executes(c -> {
                    Settings.hideHand = !Settings.hideHand;
                    Settings.save();
                    return say(c, "Прятать обычную руку при трекинге: " + (Settings.hideHand ? "да" : "нет"));
                }))
                .then(Commands.literal("ipd").then(Commands.argument("metres", FloatArgumentType.floatArg(0.0f, 0.2f))
                        .executes(c -> {
                            Settings.ipd = FloatArgumentType.getFloat(c, "metres");
                            Settings.save();
                            return say(c, "IPD: " + Settings.ipd);
                        })))
                .then(Commands.literal("hud").then(Commands.argument("shift", FloatArgumentType.floatArg(-30f, 30f))
                        .executes(c -> {
                            Settings.hudShift = FloatArgumentType.getFloat(c, "shift");
                            Settings.save();
                            return say(c, "Сдвиг HUD: " + Settings.hudShift);
                        })))
                .then(Commands.literal("smooth").then(Commands.argument("k", FloatArgumentType.floatArg(2f, 80f))
                        .executes(c -> {
                            Settings.smooth = FloatArgumentType.getFloat(c, "k");
                            Settings.save();
                            return say(c, "Сглаживание рук: " + Settings.smooth + " (меньше = плавнее)");
                        })))
                .then(Commands.literal("status").executes(c -> {
                    TrackingState.Snap s = TrackingState.get();
                    String t = TrackingState.active()
                            ? "трекинг идёт (правая " + ((s.flags() & 1) != 0 ? "да" : "нет")
                            + ", левая " + ((s.flags() & 2) != 0 ? "да" : "нет") + ")"
                            : "данных нет";
                    return say(c, "ArmVR: " + t + "; стерео " + (Settings.stereo ? "ВКЛ" : "выкл")
                            + "; IPD " + Settings.ipd + "; HUD " + Settings.hudShift);
                })));
    }
}
