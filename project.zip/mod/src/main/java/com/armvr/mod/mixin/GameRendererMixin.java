package com.armvr.mod.mixin;

import com.armvr.mod.StereoState;
import com.mojang.blaze3d.platform.Window;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GameRenderer;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Рисует мир два раза: левый глаз в левую половину окна, правый — в правую.
 * Чтобы второй проход не стёр первый, ограничиваем очистку буфера ножницами (scissor).
 */
@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {
    @Shadow
    public abstract void renderLevel(DeltaTracker deltaTracker);

    @Inject(method = "renderLevel(Lnet/minecraft/client/DeltaTracker;)V", at = @At("HEAD"), cancellable = true)
    private void armvr$twoEyes(DeltaTracker dt, CallbackInfo ci) {
        if (StereoState.inLevelPass || !StereoState.active()) return;
        Window w = Minecraft.getInstance().getWindow();
        int width = w.getWidth();
        int height = w.getHeight();
        int half = width / 2;
        StereoState.inLevelPass = true;
        try {
            for (int eye = 0; eye < 2; eye++) {
                StereoState.eye = eye;
                int x = eye == 0 ? 0 : half;
                RenderSystem.viewport(x, 0, half, height);
                RenderSystem.enableScissor(x, 0, half, height);
                this.renderLevel(dt);
            }
        } finally {
            StereoState.inLevelPass = false;
            StereoState.eye = -1;
            RenderSystem.disableScissor();
            RenderSystem.viewport(0, 0, width, height);
        }
        ci.cancel();
    }

    /** Окно глаза в два раза уже, значит аспект в два раза меньше: растягиваем проекцию по X. */
    @Inject(method = "getProjectionMatrix(D)Lorg/joml/Matrix4f;", at = @At("RETURN"), cancellable = true)
    private void armvr$halfAspect(double fov, CallbackInfoReturnable<Matrix4f> cir) {
        if (!StereoState.inLevelPass) return;
        Matrix4f m = cir.getReturnValue();
        m.m00(m.m00() * 2.0f);
        cir.setReturnValue(m);
    }
}
