package com.armvr.mod;

/** Последний принятый пакет трекинга. Пишет сетевой поток, читает рендер. */
public final class TrackingState {
    public record Snap(int flags, float[] d, int seq) {}

    private static volatile Snap snap;
    private static volatile long lastValidNanos = 0L;

    private TrackingState() {}

    public static void set(int flags, float[] d, int seq) {
        snap = new Snap(flags, d, seq);
        if ((flags & 3) != 0) lastValidNanos = System.nanoTime();
    }

    public static Snap get() {
        return snap;
    }

    /** Есть ли свежие данные хотя бы по одной руке (с запасом 0.8 с на короткие потери). */
    public static boolean active() {
        return snap != null && lastValidNanos != 0L && (System.nanoTime() - lastValidNanos) < 800_000_000L;
    }
}
