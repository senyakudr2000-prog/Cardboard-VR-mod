package com.armvr.mod;

import net.neoforged.fml.loading.FMLPaths;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** Простые настройки в config/armvr.properties. Меняются командами /armvr ... */
public final class Settings {
    public static volatile boolean stereo = false;   // режим двух глаз
    public static volatile boolean arms = true;      // рисовать руки по трекингу
    public static volatile boolean hideHand = true;  // прятать обычную руку, пока идёт трекинг
    public static volatile float ipd = 0.063f;       // расстояние между глазами, блоки (≈ метры)
    public static volatile float hudShift = 4f;      // сдвиг HUD между глазами (в px интерфейса), >0 = дальше
    public static volatile float smooth = 20f;       // сглаживание рук в моде, больше = резче
    public static volatile int port = 7001;          // UDP-порт, на который шлёт «Коннект»

    private Settings() {}

    private static Path file() {
        return FMLPaths.CONFIGDIR.get().resolve("armvr.properties");
    }

    public static void load() {
        Path f = file();
        if (!Files.exists(f)) {
            save();
            return;
        }
        Properties p = new Properties();
        try (InputStream in = Files.newInputStream(f)) {
            p.load(in);
            stereo = Boolean.parseBoolean(p.getProperty("stereo", "false"));
            arms = Boolean.parseBoolean(p.getProperty("arms", "true"));
            hideHand = Boolean.parseBoolean(p.getProperty("hideHand", "true"));
            ipd = Float.parseFloat(p.getProperty("ipd", "0.063"));
            hudShift = Float.parseFloat(p.getProperty("hudShift", "4"));
            smooth = Float.parseFloat(p.getProperty("smooth", "20"));
            port = Integer.parseInt(p.getProperty("port", "7001"));
        } catch (IOException | RuntimeException e) {
            ArmVrMod.LOGGER.warn("ArmVR: не удалось прочитать настройки, использую значения по умолчанию", e);
        }
    }

    public static void save() {
        Properties p = new Properties();
        p.setProperty("stereo", Boolean.toString(stereo));
        p.setProperty("arms", Boolean.toString(arms));
        p.setProperty("hideHand", Boolean.toString(hideHand));
        p.setProperty("ipd", Float.toString(ipd));
        p.setProperty("hudShift", Float.toString(hudShift));
        p.setProperty("smooth", Float.toString(smooth));
        p.setProperty("port", Integer.toString(port));
        try (OutputStream out = Files.newOutputStream(file())) {
            p.store(out, "ArmVR settings");
        } catch (IOException e) {
            ArmVrMod.LOGGER.warn("ArmVR: не удалось сохранить настройки", e);
        }
    }
}
