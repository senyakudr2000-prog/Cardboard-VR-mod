package com.armvr.mod;

import com.mojang.logging.LogUtils;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.neoforge.common.NeoForge;
import org.slf4j.Logger;

@Mod(value = ArmVrMod.MODID, dist = Dist.CLIENT)
public class ArmVrMod {
    public static final String MODID = "armvr";
    public static final Logger LOGGER = LogUtils.getLogger();

    public ArmVrMod(IEventBus modBus, ModContainer container) {
        Settings.load();
        modBus.addListener(ClientEvents::registerKeys);
        modBus.addListener(this::clientSetup);
        NeoForge.EVENT_BUS.register(ClientEvents.class);
        NeoForge.EVENT_BUS.register(ArmRenderer.class);
    }

    private void clientSetup(FMLClientSetupEvent event) {
        TrackingReceiver.start();
    }
}
