package com.armvr.mod.mixin;

import com.armvr.mod.Settings;
import com.armvr.mod.StereoState;
import net.minecraft.client.Camera;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Сдвигает камеру влево/вправо на половину IPD для каждого глаза. */
@Mixin(Camera.class)
public abstract class CameraMixin {
    @Shadow
    protected abstract void setPosition(double x, double y, double z);

    @Inject(method = "setup", at = @At("TAIL"))
    private void armvr$eyeOffset(BlockGetter level, Entity entity, boolean detached, boolean mirrored,
                                 float partialTick, CallbackInfo ci) {
        if (!StereoState.inLevelPass || StereoState.eye < 0) return;
        Camera self = (Camera) (Object) this;
        Vector3f left = self.getLeftVector();
        Vec3 p = self.getPosition();
        double s = (StereoState.eye == 0 ? 1.0 : -1.0) * Settings.ipd * 0.5;
        this.setPosition(p.x + left.x() * s, p.y + left.y() * s, p.z + left.z() * s);
    }
}
