package com.armvr.mod;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.SocketTimeoutException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/**
 * Слушает UDP на 127.0.0.1:port (по умолчанию 7001). Сюда шлёт приложение «Коннект» на этом же телефоне.
 * Формат пакета описан в tracker-app (Net.kt): 56 байт, little-endian.
 */
public final class TrackingReceiver {
    private static Thread thread;
    private static final byte[] ACK = "ARMVR-MOD".getBytes();

    private TrackingReceiver() {}

    public static synchronized void start() {
        if (thread != null) return;
        thread = new Thread(TrackingReceiver::run, "armvr-udp");
        thread.setDaemon(true);
        thread.start();
    }

    private static void run() {
        byte[] buf = new byte[256];
        long lastAck = 0L;
        while (true) {
            try (DatagramSocket s = new DatagramSocket(new InetSocketAddress(InetAddress.getLoopbackAddress(), Settings.port))) {
                s.setSoTimeout(1000);
                ArmVrMod.LOGGER.info("ArmVR: слушаю трекинг на 127.0.0.1:{}", Settings.port);
                while (true) {
                    DatagramPacket p = new DatagramPacket(buf, buf.length);
                    try {
                        s.receive(p);
                    } catch (SocketTimeoutException e) {
                        continue;
                    }
                    handle(buf, p.getLength());
                    long now = System.nanoTime();
                    if (now - lastAck > 1_000_000_000L) {
                        lastAck = now;
                        s.send(new DatagramPacket(ACK, ACK.length, p.getSocketAddress()));
                    }
                }
            } catch (Exception e) {
                ArmVrMod.LOGGER.warn("ArmVR: ошибка сокета, повтор через 2 с: {}", e.toString());
                try {
                    Thread.sleep(2000);
                } catch (InterruptedException ie) {
                    return;
                }
            }
        }
    }

    private static void handle(byte[] b, int len) {
        if (len < 56 || b[0] != 'A' || b[1] != 'R' || b[2] != 'M' || b[3] != 'T') return;
        ByteBuffer bb = ByteBuffer.wrap(b, 4, len - 4).order(ByteOrder.LITTLE_ENDIAN);
        int version = bb.get();
        if (version != 1) return;
        int flags = bb.get() & 0xFF;
        int seq = bb.getShort() & 0xFFFF;
        float[] d = new float[12];
        for (int i = 0; i < 12; i++) {
            float v = bb.getFloat();
            if (Float.isNaN(v) || Float.isInfinite(v)) return;
            d[i] = v;
        }
        TrackingState.set(flags, d, seq);
    }
}
