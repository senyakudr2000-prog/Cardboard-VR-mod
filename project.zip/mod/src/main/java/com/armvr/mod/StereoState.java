package com.armvr.mod;

import net.minecraft.client.Minecraft;

/** Состояние стерео-прохода. Всё читается и пишется только из потока рендера. */
public final class StereoState {
    /** Идёт отрисовка мира для одного из глаз. */
    public static boolean inLevelPass = false;
    /** Идёт отрисовка HUD для одного из глаз. */
    public static boolean inHudPass = false;
    /** 0 = левый глаз, 1 = правый, -1 = не стерео. */
    public static int eye = -1;

    private StereoState() {}

    /** Стерео работает, только когда в мире и нет открытых экранов (меню/инвентарь/чат рисуются обычно). */
    public static boolean active() {
        Minecraft mc = Minecraft.getInstance();
        return Settings.stereo && mc.level != null && mc.screen == null;
    }
}
