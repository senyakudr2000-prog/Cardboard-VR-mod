package com.armvr.mod.mixin;

import com.armvr.mod.Settings;
import com.armvr.mod.StereoState;
import com.mojang.blaze3d.platform.Window;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiGraphics;
import com.mojang.blaze3d.vertex.VertexSorting;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * HUD рисуется для каждого глаза отдельно: берём центральную половину интерфейса
 * (хотбар, сердца, прицел) и чуть сдвигаем между глазами, чтобы HUD «висел» на расстоянии.
 */
@Mixin(Gui.class)
public abstract class GuiMixin {
    @Shadow
    public abstract void render(GuiGraphics graphics, DeltaTracker deltaTracker);

    @Inject(method = "render(Lnet/minecraft/client/gui/GuiGraphics;Lnet/minecraft/client/DeltaTracker;)V",
            at = @At("HEAD"), cancellable = true)
    private void armvr$hudPerEye(GuiGraphics g, DeltaTracker dt, CallbackInfo ci) {
        if (StereoState.inHudPass || !StereoState.active()) return;
        Window w = Minecraft.getInstance().getWindow();
        int width = w.getWidth();
        int height = w.getHeight();
        int half = width / 2;
        float gw = (float) (width / w.getGuiScale());
        float gh = (float) (height / w.getGuiScale());
        StereoState.inHudPass = true;
        try {
            for (int eye = 0; eye < 2; eye++) {
                int x = eye == 0 ? 0 : half;
                RenderSystem.viewport(x, 0, half, height);
                RenderSystem.enableScissor(x, 0, half, height);
                float shift = (eye == 0 ? 1f : -1f) * Settings.hudShift;
                Matrix4f proj = new Matrix4f().setOrtho(gw * 0.25f + shift, gw * 0.75f + shift, gh, 0f, 1000f, 21000f);
                RenderSystem.setProjectionMatrix(proj, VertexSorting.ORTHOGRAPHIC_Z);
                this.render(g, dt);
                g.flush();
            }
        } finally {
            StereoState.inHudPass = false;
            RenderSystem.disableScissor();
            RenderSystem.viewport(0, 0, width, height);
            Matrix4f full = new Matrix4f().setOrtho(0f, gw, gh, 0f, 1000f, 21000f);
            RenderSystem.setProjectionMatrix(full, VertexSorting.ORTHOGRAPHIC_Z);
        }
        ci.cancel();
    }
}
