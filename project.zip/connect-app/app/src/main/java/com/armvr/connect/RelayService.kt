package com.armvr.connect

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.wifi.WifiManager
import android.os.IBinder
import android.os.PowerManager
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.SocketTimeoutException
import kotlin.concurrent.thread

object Relay {
    const val LISTEN_PORT = 7000   // сюда шлёт приложение-трекер
    const val MOD_PORT = 7001      // здесь слушает мод внутри Zalith (localhost)

    @Volatile var running = false
    @Volatile var received = 0L
    @Volatile var forwarded = 0L
    @Volatile var lastRxMs = 0L
    @Volatile var modAckMs = 0L
    @Volatile var error = ""
}

/**
 * Принимает пакеты трекинга по Wi-Fi и пересылает их без изменений на 127.0.0.1:7001, где их ждёт мод.
 * Работает как foreground-сервис, чтобы Android не убил его, когда на экране Zalith.
 */
class RelayService : Service() {
    private var rx: DatagramSocket? = null
    private var tx: DatagramSocket? = null
    private var wake: PowerManager.WakeLock? = null
    private var wifi: WifiManager.WifiLock? = null
    @Volatile private var alive = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (alive) return START_STICKY
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("relay", "ArmVR Коннект", NotificationManager.IMPORTANCE_LOW))
        val n: Notification = NotificationCompat.Builder(this, "relay")
            .setContentTitle("ArmVR Коннект работает")
            .setContentText("Передаю трекинг в Minecraft")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setOngoing(true)
            .build()
        ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)

        wake = (getSystemService(Context.POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "armvr:relay").apply { acquire() }
        @Suppress("DEPRECATION")
        wifi = (applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager)
            .createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "armvr:wifi").apply { acquire() }

        alive = true
        Relay.running = true
        Relay.error = ""
        Relay.received = 0; Relay.forwarded = 0
        thread(name = "armvr-relay") { loop() }
        return START_STICKY
    }

    private fun loop() {
        try {
            val r = DatagramSocket(null).apply {
                reuseAddress = true
                bind(InetSocketAddress(Relay.LISTEN_PORT))
            }
            val t = DatagramSocket()
            rx = r; tx = t
            val mod = InetSocketAddress(InetAddress.getByName("127.0.0.1"), Relay.MOD_PORT)

            // ответы мода («мод жив») приходят на сокет отправки
            thread(name = "armvr-ack") {
                val b = ByteArray(32)
                t.soTimeout = 1000
                while (alive) {
                    try {
                        val p = DatagramPacket(b, b.size)
                        t.receive(p)
                        if (String(p.data, 0, p.length).startsWith("ARMVR-MOD")) Relay.modAckMs = SystemClock.elapsedRealtime()
                    } catch (_: SocketTimeoutException) {
                    } catch (_: Exception) {
                        break
                    }
                }
            }

            val buf = ByteArray(512)
            while (alive) {
                val p = DatagramPacket(buf, buf.size)
                r.receive(p)
                val len = p.length
                if (len >= 6 && buf[0] == 'A'.code.toByte() && buf[1] == 'R'.code.toByte() &&
                    buf[2] == 'M'.code.toByte() && buf[3] == 'V'.code.toByte() && buf[4] == 'R'.code.toByte()
                ) {
                    // "ARMVR?" — поиск от трекера
                    val reply = "ARMVR!".toByteArray()
                    r.send(DatagramPacket(reply, reply.size, p.socketAddress))
                } else if (len >= 56 && buf[0] == 'A'.code.toByte() && buf[1] == 'R'.code.toByte() &&
                    buf[2] == 'M'.code.toByte() && buf[3] == 'T'.code.toByte()
                ) {
                    Relay.received++
                    Relay.lastRxMs = SystemClock.elapsedRealtime()
                    t.send(DatagramPacket(buf, len, mod))
                    Relay.forwarded++
                }
            }
        } catch (e: Exception) {
            if (alive) Relay.error = "Ошибка: ${e.message}"
        } finally {
            closeSockets()
        }
    }

    private fun closeSockets() {
        try { rx?.close() } catch (_: Exception) {}
        try { tx?.close() } catch (_: Exception) {}
    }

    override fun onDestroy() {
        alive = false
        Relay.running = false
        closeSockets()
        try { wake?.release() } catch (_: Exception) {}
        try { wifi?.release() } catch (_: Exception) {}
        super.onDestroy()
    }
}
