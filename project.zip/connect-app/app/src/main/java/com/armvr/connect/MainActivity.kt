package com.armvr.connect

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import java.net.Inet4Address
import java.net.NetworkInterface

class MainActivity : ComponentActivity() {
    private lateinit var info: TextView
    private lateinit var toggle: Button
    private val ui = Handler(Looper.getMainLooper())
    private var lastCount = 0L
    private var lastTick = 0L
    private var rate = 0

    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private val ticker = object : Runnable {
        override fun run() {
            val now = SystemClock.elapsedRealtime()
            if (lastTick != 0L) {
                rate = ((Relay.received - lastCount) * 1000 / (now - lastTick).coerceAtLeast(1)).toInt()
            }
            lastCount = Relay.received; lastTick = now
            render(now)
            ui.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        setContentView(buildUi())
        ui.post(ticker)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildUi(): View {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(16))
            setBackgroundColor(Color.rgb(18, 18, 18))
        }
        col.addView(TextView(this).apply { text = "ArmVR Коннект"; textSize = 22f; setTextColor(Color.WHITE) })
        info = TextView(this).apply { textSize = 15f; setTextColor(Color.LTGRAY); setPadding(0, dp(12), 0, dp(12)) }
        col.addView(info)
        toggle = Button(this).apply {
            setOnClickListener {
                val i = Intent(this@MainActivity, RelayService::class.java)
                if (Relay.running) stopService(i) else ContextCompat.startForegroundService(this@MainActivity, i)
            }
        }
        col.addView(toggle)
        col.addView(Button(this).apply {
            text = "Настройки батареи (разрешить работу в фоне)"
            setOnClickListener { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
        })
        col.addView(TextView(this).apply {
            textSize = 13f; setTextColor(Color.GRAY); setPadding(0, dp(16), 0, 0)
            text = "1. Нажмите «Запустить».\n" +
                "2. На втором телефоне в приложении «Трекер» нажмите «Найти» (или введите IP отсюда) и «Старт».\n" +
                "3. Запустите Minecraft с модом ArmVR в Zalith. Статус «Мод получает данные» означает, что всё работает.\n\n" +
                "Оба телефона должны быть в одной Wi-Fi сети. Лучше раздавать Wi-Fi с одного из телефонов или использовать роутер 5 ГГц."
        })
        return ScrollView(this).apply {
            setBackgroundColor(Color.rgb(18, 18, 18))
            addView(col, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
    }

    private fun localIps(): List<String> = try {
        NetworkInterface.getNetworkInterfaces()?.toList().orEmpty()
            .filter { it.isUp && !it.isLoopback }
            .flatMap { it.inetAddresses.toList() }
            .filter { it is Inet4Address && !it.isLoopbackAddress }
            .mapNotNull { it.hostAddress }
    } catch (e: Exception) {
        emptyList()
    }

    private fun render(now: Long) {
        toggle.text = if (Relay.running) "Остановить" else "Запустить"
        val ips = localIps().joinToString(", ").ifEmpty { "нет Wi-Fi сети" }
        val sb = StringBuilder()
        sb.append("IP этого телефона: ").append(ips).append("\nПорт: ").append(Relay.LISTEN_PORT).append("\n\n")
        if (!Relay.running) {
            sb.append("Состояние: остановлено")
        } else {
            val trackerAlive = Relay.lastRxMs != 0L && now - Relay.lastRxMs < 1500
            val modAlive = Relay.modAckMs != 0L && now - Relay.modAckMs < 3000
            sb.append("Трекер: ").append(if (trackerAlive) "данные идут ($rate пак/с)" else "ждём данные…").append('\n')
            sb.append("Мод: ").append(if (modAlive) "получает данные" else "не отвечает (запущен ли Minecraft с модом?)").append('\n')
            sb.append("Принято: ").append(Relay.received).append(", переслано: ").append(Relay.forwarded)
        }
        if (Relay.error.isNotEmpty()) sb.append("\n").append(Relay.error)
        info.text = sb.toString()
    }

    override fun onDestroy() {
        super.onDestroy()
        ui.removeCallbacks(ticker)
    }
}
