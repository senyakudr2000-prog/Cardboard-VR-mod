package com.armvr.tracker

import android.os.SystemClock
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.SocketTimeoutException
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Формат пакета (little-endian, 56 байт):
 *  0..3  'A','R','M','T'
 *  4     версия = 1
 *  5     флаги: bit0 = правая рука валидна, bit1 = левая
 *  6..7  счётчик пакетов (u16)
 *  8..55 12 float: [правая верх xyz][правая низ xyz][левая верх xyz][левая низ xyz]
 *        xyz = (вправо, вверх, вперёд) в системе тела, единичные векторы
 */
object Proto {
    const val PORT = 7000

    fun encode(seq: Int, flags: Int, d: FloatArray): ByteArray {
        val b = ByteBuffer.allocate(56).order(ByteOrder.LITTLE_ENDIAN)
        b.put('A'.code.toByte()).put('R'.code.toByte()).put('M'.code.toByte()).put('T'.code.toByte())
        b.put(1.toByte())
        b.put(flags.toByte())
        b.putShort(seq.toShort())
        for (i in 0 until 12) b.putFloat(d[i])
        return b.array()
    }
}

class UdpLink {
    private val socket = DatagramSocket()
    @Volatile private var target: InetAddress? = null

    /** Вызывать не из главного потока. */
    fun setHost(host: String): Boolean = try {
        target = InetAddress.getByName(host.trim())
        true
    } catch (e: Exception) {
        target = null
        false
    }

    fun send(data: ByteArray) {
        val t = target ?: return
        try {
            socket.send(DatagramPacket(data, data.size, t, Proto.PORT))
        } catch (_: Exception) {
        }
    }

    fun close() {
        try { socket.close() } catch (_: Exception) {}
    }

    companion object {
        /** Ищет приложение «Коннект» в Wi-Fi сети широковещательным запросом. Не из главного потока. */
        fun discover(timeoutMs: Int): String? {
            DatagramSocket().use { s ->
                s.broadcast = true
                s.soTimeout = 400
                val q = "ARMVR?".toByteArray()
                val end = SystemClock.elapsedRealtime() + timeoutMs
                while (SystemClock.elapsedRealtime() < end) {
                    try {
                        s.send(DatagramPacket(q, q.size, InetAddress.getByName("255.255.255.255"), Proto.PORT))
                    } catch (_: Exception) {
                    }
                    val p = DatagramPacket(ByteArray(64), 64)
                    try {
                        s.receive(p)
                        if (String(p.data, 0, p.length).startsWith("ARMVR!")) return p.address.hostAddress
                    } catch (_: SocketTimeoutException) {
                    } catch (_: Exception) {
                        return null
                    }
                }
            }
            return null
        }
    }
}
