package com.armvr.tracker

import kotlin.math.PI
import kotlin.math.abs

/** Фильтр One Euro: гасит дрожание на медленных движениях, не добавляет лаг на быстрых. */
class OneEuro(@Volatile var minCutoff: Double = 1.5, @Volatile var beta: Double = 3.0, private val dCutoff: Double = 1.0) {
    private var xPrev = 0.0
    private var dxPrev = 0.0
    private var tPrev = -1.0

    private fun alpha(cutoff: Double, dt: Double): Double {
        val tau = 1.0 / (2.0 * PI * cutoff)
        return 1.0 / (1.0 + tau / dt)
    }

    fun filter(x: Double, t: Double): Double {
        if (tPrev < 0) {
            xPrev = x; dxPrev = 0.0; tPrev = t
            return x
        }
        val dt = (t - tPrev).coerceAtLeast(1e-3)
        tPrev = t
        val dx = (x - xPrev) / dt
        dxPrev += alpha(dCutoff, dt) * (dx - dxPrev)
        val cutoff = minCutoff + beta * abs(dxPrev)
        xPrev += alpha(cutoff, dt) * (x - xPrev)
        return xPrev
    }

    fun reset() {
        tPrev = -1.0
    }
}
