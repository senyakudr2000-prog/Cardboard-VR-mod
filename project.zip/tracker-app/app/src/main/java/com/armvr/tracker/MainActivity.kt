package com.armvr.tracker

import android.Manifest
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Matrix
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Size
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import java.nio.ByteBuffer
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.concurrent.thread

class MainActivity : ComponentActivity() {
    private lateinit var overlay: OverlayView
    private lateinit var status: TextView
    private lateinit var ipEdit: EditText
    private lateinit var startBtn: Button
    private lateinit var modelSpin: Spinner
    private lateinit var frontCb: CheckBox
    private lateinit var previewCb: CheckBox
    private lateinit var smoothSeek: SeekBar

    private val link = UdpLink()
    private var engine: PoseEngine? = null
    private var analysis: ImageAnalysis? = null
    private var provider: ProcessCameraProvider? = null
    private val camExec: ExecutorService = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())

    @Volatile private var running = false
    private var seq = 0
    private var lastTs = 0L
    @Volatile private var frames = 0
    @Volatile private var lastFlags = 0
    @Volatile private var lastError = ""

    private val prefs by lazy { getSharedPreferences("armvr", MODE_PRIVATE) }
    private val modelIds = arrayOf("lite", "full", "heavy")
    private val modelTitles = arrayOf("Лёгкая (быстро)", "Средняя (рекомендую)", "Тяжёлая (точнее, медленнее)")

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) startTracking() else toast("Нужен доступ к камере")
    }

    private val ticker = object : Runnable {
        override fun run() {
            val f = frames; frames = 0
            val fl = lastFlags
            val sb = StringBuilder()
            if (running) {
                sb.append("FPS: ").append(f * 2)
                sb.append("  |  правая рука: ").append(if (fl and 1 != 0) "да" else "нет")
                sb.append(", левая: ").append(if (fl and 2 != 0) "да" else "нет")
                engine?.let { sb.append("\nGPU: ").append(if (it.usingGpu) "да" else "нет (CPU)") }
            } else sb.append("Остановлено")
            if (lastError.isNotEmpty()) sb.append("\n").append(lastError)
            status.text = sb.toString()
            ui.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(buildUi())
        ui.post(ticker)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildUi(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(18, 18, 18))
        }
        overlay = OverlayView(this)
        root.addView(overlay, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }
        status = TextView(this).apply { setTextColor(Color.WHITE); textSize = 13f }
        panel.addView(status)

        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        ipEdit = EditText(this).apply {
            hint = "IP телефона с Minecraft"
            setHintTextColor(Color.GRAY); setTextColor(Color.WHITE)
            setSingleLine(); inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            setText(prefs.getString("ip", ""))
        }
        row1.addView(ipEdit, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val findBtn = Button(this).apply { text = "Найти"; setOnClickListener { findConnect() } }
        row1.addView(findBtn)
        panel.addView(row1)

        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        modelSpin = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, modelTitles)
            setSelection(prefs.getInt("model", 1))
        }
        row2.addView(modelSpin, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        frontCb = CheckBox(this).apply { text = "Фронт."; setTextColor(Color.WHITE); isChecked = prefs.getBoolean("front", false) }
        previewCb = CheckBox(this).apply {
            text = "Видео"; setTextColor(Color.WHITE); isChecked = prefs.getBoolean("preview", true)
            setOnCheckedChangeListener { _, c -> overlay.showImage = c }
        }
        overlay.showImage = previewCb.isChecked
        row2.addView(frontCb)
        row2.addView(previewCb)
        panel.addView(row2)

        panel.addView(TextView(this).apply { text = "Сглаживание (слева — быстрее, справа — плавнее)"; setTextColor(Color.LTGRAY); textSize = 12f })
        smoothSeek = SeekBar(this).apply {
            max = 100; progress = prefs.getInt("smooth", 50)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { engine?.solver?.setSmoothing(p) }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        panel.addView(smoothSeek)

        startBtn = Button(this).apply { text = "Старт"; setOnClickListener { if (running) stopTracking() else requestStart() } }
        panel.addView(startBtn)
        root.addView(panel, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        return root
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun findConnect() {
        toast("Ищу приложение «Коннект»…")
        thread {
            val ip = UdpLink.discover(3000)
            runOnUiThread {
                if (ip != null) { ipEdit.setText(ip); toast("Найдено: $ip") }
                else toast("Не найдено. Введите IP вручную (он показан в приложении «Коннект»)")
            }
        }
    }

    private fun requestStart() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) startTracking()
        else permLauncher.launch(Manifest.permission.CAMERA)
    }

    private fun startTracking() {
        val ip = ipEdit.text.toString().trim()
        if (ip.isEmpty()) { toast("Введите IP телефона с Minecraft или нажмите «Найти»"); return }
        val model = modelIds[modelSpin.selectedItemPosition]
        val front = frontCb.isChecked
        prefs.edit().putString("ip", ip).putInt("model", modelSpin.selectedItemPosition)
            .putBoolean("front", front).putBoolean("preview", previewCb.isChecked)
            .putInt("smooth", smoothSeek.progress).apply()
        startBtn.isEnabled = false
        lastError = ""
        overlay.mirror = front
        thread {
            try {
                link.setHost(ip)
                val eng = PoseEngine(this, model, ::onFrame) { lastError = it }
                eng.solver.setSmoothing(smoothSeek.progress)
                engine = eng
                runOnUiThread { bindCamera(front) }
            } catch (e: Exception) {
                lastError = "Не удалось загрузить модель: ${e.message}"
                runOnUiThread { startBtn.isEnabled = true }
            }
        }
    }

    private fun bindCamera(front: Boolean) {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                val prov = future.get()
                provider = prov
                val sel = if (front) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
                val a = ImageAnalysis.Builder()
                    .setResolutionSelector(
                        ResolutionSelector.Builder()
                            .setResolutionStrategy(
                                ResolutionStrategy(Size(640, 480), ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER)
                            ).build()
                    )
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                    .build()
                a.setAnalyzer(camExec) { analyze(it) }
                analysis = a
                prov.unbindAll()
                prov.bindToLifecycle(this, sel, a)
                running = true
                startBtn.text = "Стоп"
                startBtn.isEnabled = true
            } catch (e: Exception) {
                lastError = "Камера: ${e.message}"
                startBtn.isEnabled = true
                engine?.close(); engine = null
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun stopTracking() {
        running = false
        provider?.unbindAll()
        analysis = null
        val e = engine
        engine = null
        thread { e?.close() }
        startBtn.text = "Старт"
        lastFlags = 0
        // сообщаем моду, что поза потеряна
        thread { link.send(Proto.encode(seq++ and 0xFFFF, 0, FloatArray(12))) }
    }

    private fun analyze(proxy: ImageProxy) {
        val eng = engine
        if (!running || eng == null) { proxy.close(); return }
        try {
            val plane = proxy.planes[0]
            val stride = plane.rowStride / plane.pixelStride
            val raw = Bitmap.createBitmap(stride, proxy.height, Bitmap.Config.ARGB_8888)
            if (stride == proxy.width) {
                raw.copyPixelsFromBuffer(plane.buffer)
            } else {
                val need = plane.rowStride * proxy.height
                val bytes = ByteArray(need)
                plane.buffer.get(bytes, 0, minOf(plane.buffer.remaining(), need))
                raw.copyPixelsFromBuffer(ByteBuffer.wrap(bytes))
            }
            val m = Matrix().apply { postRotate(proxy.imageInfo.rotationDegrees.toFloat()) }
            val upright = Bitmap.createBitmap(raw, 0, 0, proxy.width, proxy.height, m, true)
            raw.recycle()
            val now = SystemClock.uptimeMillis()
            val ts = if (now <= lastTs) lastTs + 1 else now
            lastTs = ts
            overlay.setFrame(upright)
            eng.detect(upright, ts)
        } catch (e: Exception) {
            lastError = "Кадр: ${e.message}"
        } finally {
            proxy.close()
        }
    }

    private fun onFrame(f: PoseEngine.Frame) {
        link.send(Proto.encode(seq++ and 0xFFFF, f.solved.flags, f.solved.dirs))
        lastFlags = f.solved.flags
        frames++
        overlay.setLandmarks(f.norm)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        @Suppress("DEPRECATION")
        analysis?.targetRotation = windowManager.defaultDisplay.rotation
    }

    override fun onDestroy() {
        super.onDestroy()
        ui.removeCallbacks(ticker)
        running = false
        provider?.unbindAll()
        engine?.close()
        link.close()
        camExec.shutdown()
    }
}
