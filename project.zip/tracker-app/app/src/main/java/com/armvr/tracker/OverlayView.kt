package com.armvr.tracker

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
import com.google.mediapipe.tasks.components.containers.NormalizedLandmark

/** Показывает кадр, который видит модель, и поверх него скелет верхней части тела. */
class OverlayView(context: Context) : View(context) {
    @Volatile private var bmp: Bitmap? = null
    @Volatile private var lm: List<NormalizedLandmark>? = null
    var mirror = false
    var showImage = true

    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeWidth = 8f; style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; style = Paint.Style.FILL }
    private val dst = RectF()

    // правая рука человека — зелёная, левая — оранжевая, торс — серый
    private val bones = arrayOf(
        intArrayOf(12, 14, Color.GREEN), intArrayOf(14, 16, Color.GREEN),
        intArrayOf(11, 13, Color.rgb(255, 160, 0)), intArrayOf(13, 15, Color.rgb(255, 160, 0)),
        intArrayOf(11, 12, Color.LTGRAY), intArrayOf(23, 24, Color.LTGRAY),
        intArrayOf(11, 23, Color.LTGRAY), intArrayOf(12, 24, Color.LTGRAY)
    )

    fun setFrame(b: Bitmap) { bmp = b; postInvalidateOnAnimation() }
    fun setLandmarks(l: List<NormalizedLandmark>?) { lm = l; postInvalidateOnAnimation() }

    override fun onDraw(c: Canvas) {
        c.drawColor(Color.BLACK)
        val b = bmp ?: return
        val s = minOf(width.toFloat() / b.width, height.toFloat() / b.height)
        val w = b.width * s
        val h = b.height * s
        val l = (width - w) / 2f
        val t = (height - h) / 2f
        dst.set(l, t, l + w, t + h)
        c.save()
        if (mirror) c.scale(-1f, 1f, width / 2f, height / 2f)
        if (showImage) c.drawBitmap(b, null, dst, null)
        val pts = lm
        if (pts != null && pts.size >= 25) {
            for (bone in bones) {
                val a = pts[bone[0]]; val d = pts[bone[1]]
                line.color = bone[2]
                c.drawLine(l + a.x() * w, t + a.y() * h, l + d.x() * w, t + d.y() * h, line)
            }
            for (i in intArrayOf(11, 12, 13, 14, 15, 16, 23, 24)) {
                c.drawCircle(l + pts[i].x() * w, t + pts[i].y() * h, 9f, dot)
            }
        }
        c.restore()
    }
}
