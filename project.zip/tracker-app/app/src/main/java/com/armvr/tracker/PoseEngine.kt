package com.armvr.tracker

import android.content.Context
import android.graphics.Bitmap
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.framework.image.MPImage
import com.google.mediapipe.tasks.components.containers.NormalizedLandmark
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.core.Delegate
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.poselandmarker.PoseLandmarker
import com.google.mediapipe.tasks.vision.poselandmarker.PoseLandmarkerResult

class PoseEngine(
    context: Context,
    model: String,
    private val onFrame: (Frame) -> Unit,
    private val onError: (String) -> Unit
) {
    class Frame(val norm: List<NormalizedLandmark>?, val solved: PoseSolver.Solved)

    val solver = PoseSolver()
    var usingGpu = false
        private set
    @Volatile private var landmarker: PoseLandmarker? = null

    init {
        fun make(delegate: Delegate): PoseLandmarker {
            val base = BaseOptions.builder()
                .setModelAssetPath("pose_landmarker_$model.task")
                .setDelegate(delegate)
                .build()
            val opts = PoseLandmarker.PoseLandmarkerOptions.builder()
                .setBaseOptions(base)
                .setRunningMode(RunningMode.LIVE_STREAM)
                .setNumPoses(1)
                .setMinPoseDetectionConfidence(0.5f)
                .setMinPosePresenceConfidence(0.5f)
                .setMinTrackingConfidence(0.5f)
                .setResultListener { result, input -> handle(result, input) }
                .setErrorListener { e -> onError(e.message ?: "ошибка MediaPipe") }
                .build()
            return PoseLandmarker.createFromOptions(context, opts)
        }
        landmarker = try {
            make(Delegate.GPU).also { usingGpu = true }
        } catch (e: Exception) {
            make(Delegate.CPU)
        }
    }

    private fun handle(result: PoseLandmarkerResult, @Suppress("UNUSED_PARAMETER") input: MPImage) {
        val world = result.worldLandmarks()
        val solved = if (world.isNotEmpty()) solver.solve(world[0], result.timestampMs() / 1000.0) else PoseSolver.EMPTY
        onFrame(Frame(result.landmarks().firstOrNull(), solved))
    }

    fun detect(bitmap: Bitmap, timestampMs: Long) {
        try {
            landmarker?.detectAsync(BitmapImageBuilder(bitmap).build(), timestampMs)
        } catch (e: Exception) {
            onError(e.message ?: "detect error")
        }
    }

    fun close() {
        val l = landmarker
        landmarker = null
        try { l?.close() } catch (_: Exception) {}
    }
}
