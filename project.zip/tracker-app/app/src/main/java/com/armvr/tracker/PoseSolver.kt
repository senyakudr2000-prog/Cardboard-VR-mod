package com.armvr.tracker

import com.google.mediapipe.tasks.components.containers.Landmark
import kotlin.math.sqrt

/**
 * Превращает 3D-точки MediaPipe (метры, начало в центре бёдер, x вправо в кадре, y вниз, z от камеры)
 * в направления сегментов рук В СИСТЕМЕ КООРДИНАТ ТЕЛА: (вправо, вверх, вперёд).
 * Система тела строится по плечам и бёдрам, поэтому не важно, как стоит телефон и как повёрнут человек.
 */
class PoseSolver {
    class Solved(val flags: Int, val dirs: FloatArray)

    companion object {
        val EMPTY = Solved(0, FloatArray(12))
        private val IDS = intArrayOf(11, 12, 13, 14, 15, 16, 23, 24)
    }

    @Volatile var minVisArm = 0.5f
    @Volatile var minVisTorso = 0.4f
    private val filters = HashMap<Int, Array<OneEuro>>()

    init {
        for (id in IDS) filters[id] = Array(3) { OneEuro(1.5, 3.0) }
    }

    /** 0 = минимум сглаживания (быстрее), 100 = максимум (плавнее). */
    fun setSmoothing(level: Int) {
        val cutoff = 4.0 - 3.4 * (level.coerceIn(0, 100) / 100.0)
        for (arr in filters.values) for (f in arr) f.minCutoff = cutoff
    }

    fun reset() {
        for (arr in filters.values) for (f in arr) f.reset()
    }

    fun solve(world: List<Landmark>, t: Double): Solved {
        if (world.size < 25) return EMPTY
        val p = arrayOfNulls<DoubleArray>(25)
        val v = FloatArray(25)
        for (id in IDS) {
            val l = world[id]
            val f = filters[id]!!
            p[id] = doubleArrayOf(
                f[0].filter(l.x().toDouble(), t),
                f[1].filter(l.y().toDouble(), t),
                f[2].filter(l.z().toDouble(), t)
            )
            v[id] = l.visibility().orElse(0f)
        }
        val tv = minVisTorso
        if (v[11] < tv || v[12] < tv || v[23] < tv * 0.75f || v[24] < tv * 0.75f) return EMPTY

        val sL = p[11]!!; val sR = p[12]!!; val hL = p[23]!!; val hR = p[24]!!
        val u = norm(sub(mid(sL, sR), mid(hL, hR))) ?: return EMPTY       // вверх (к голове)
        var a = sub(sL, sR)                                                  // к ЛЕВОМУ плечу человека
        a = sub(a, mul(u, dot(a, u)))
        val an = norm(a) ?: return EMPTY
        val f = norm(cross(an, u)) ?: return EMPTY                           // вперёд (к камере)

        var flags = 0
        val out = FloatArray(12)
        if (arm(p, v, 12, 14, 16, an, u, f, out, 0)) flags = flags or 1      // правая рука человека
        if (arm(p, v, 11, 13, 15, an, u, f, out, 6)) flags = flags or 2      // левая
        return Solved(flags, out)
    }

    private fun arm(
        p: Array<DoubleArray?>, v: FloatArray, s: Int, e: Int, w: Int,
        a: DoubleArray, u: DoubleArray, f: DoubleArray, out: FloatArray, o: Int
    ): Boolean {
        val mv = minVisArm
        if (v[s] < mv || v[e] < mv || v[w] < mv) return false
        val upper = norm(toBody(sub(p[e]!!, p[s]!!), a, u, f)) ?: return false
        val fore = norm(toBody(sub(p[w]!!, p[e]!!), a, u, f)) ?: return false
        for (i in 0..2) {
            out[o + i] = upper[i].toFloat()
            out[o + 3 + i] = fore[i].toFloat()
        }
        return true
    }

    // (вправо, вверх, вперёд): вправо = -a, потому что a смотрит на левое плечо
    private fun toBody(v: DoubleArray, a: DoubleArray, u: DoubleArray, f: DoubleArray) =
        doubleArrayOf(-dot(v, a), dot(v, u), dot(v, f))

    private fun sub(a: DoubleArray, b: DoubleArray) = doubleArrayOf(a[0] - b[0], a[1] - b[1], a[2] - b[2])
    private fun mid(a: DoubleArray, b: DoubleArray) = doubleArrayOf((a[0] + b[0]) / 2, (a[1] + b[1]) / 2, (a[2] + b[2]) / 2)
    private fun mul(a: DoubleArray, k: Double) = doubleArrayOf(a[0] * k, a[1] * k, a[2] * k)
    private fun dot(a: DoubleArray, b: DoubleArray) = a[0] * b[0] + a[1] * b[1] + a[2] * b[2]
    private fun cross(a: DoubleArray, b: DoubleArray) = doubleArrayOf(
        a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]
    )

    private fun norm(a: DoubleArray): DoubleArray? {
        val l = sqrt(dot(a, a))
        return if (l < 1e-6) null else doubleArrayOf(a[0] / l, a[1] / l, a[2] / l)
    }
}
